/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sofis_moura.atv1;

import javax.swing.JOptionPane;

/**
 *
 * @author FATEC ZONA LESTE
 */
public class Sofis_mouraAtv1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
int hora = Integer.parseInt(JOptionPane.showInputDialog("Informe a hora de inicio do turno: "));

if (hora >= 5 && hora < 13) {

JOptionPane.showMessageDialog(null, "Turno da Manhã");

} if (hora < 13 || hora >= 21) {
        } else {
            JOptionPane.showMessageDialog(null, "Turno da Tarde");
        }

} if ((hr >= 21 && hr <= 23) || (hr >= 0 && hr < 5)) {

JOptionPane.showMessageDialog(null, "Turno da Noite"); } else {

JOptionPane.showMessageDialog(null, "Inválido");
    }
    
}
